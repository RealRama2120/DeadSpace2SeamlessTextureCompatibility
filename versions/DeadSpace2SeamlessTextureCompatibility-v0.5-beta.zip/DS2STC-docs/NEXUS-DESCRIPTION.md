# Dead Space 2 Seamless Texture Compatibility — v0.5 beta

Install compatible TexMod `.tpf` packs, then start the original 32-bit PC Dead Space 2 through Steam Play. This standalone beta finds packs on each launch, validates them and starts the game through TexMod automatically. No renamed game executable, Steam launch option or separate daily launcher is needed. Exact package-priority and disable rules are available for conflicts.

**Beta scope:** During development, a controlled diagnostic texture was visibly replaced in Dead Space 2 through normal Steam Play. All ten current Return to Titan packs were selected and reached the altered title and main menu. The existing save appeared in both ordinary Steam and mod-enabled launches, and both closed normally. The newly labeled v0.5 build passed offline checks but has not yet been relaunched in the game. Return to Titan replacements during gameplay, long-session stability, the Steam overlay in the rendered process, first-run acquisition on other machines and Vortex UI deployment/purge are **not yet verified**. This is a testable beta, not a completed v1.0 compatibility claim. See `DS2STC-docs/TEST-REPORT.md` in the ZIP.

## Installation

Close the game. For manual installation, extract the ZIP into the folder containing `deadspace2.exe` and `DS2DAT0.DAT`. It places `version.dll`, `DS2TextureLauncher.exe`, `DS2SeamlessTextures.json` and a documentation folder at the game root. If `version.dll` already exists, resolve that conflict first; do not overwrite another mod's version proxy.

The same ZIP has been checked against the separate Dead Space 2 Vortex game-support extension's installer mapping. If you use that extension, install, enable and deploy it as a game-root mod. A live Vortex UI installation and purge have not yet been verified. Manual installation is the route used in the Steam tests.

Install texture packs separately, for example under `TexMod Packages`. Game-root `.tpf` files and subfolders of `TexMod Packages`, `TexturePacks` and `Mods` are scanned on every launch. The ZIP contains no texture packs. Known obsolete Return to Titan packages are excluded only when their exact audited replacement content is present.

Launch through Steam normally. The mod reuses a checksum-verified original `Texmod.exe` if available. Otherwise, first launch asks consent to retrieve the archived TexMod 0.9b over HTTPS and verifies pinned hashes. Declining cancels the texture-enabled launch. TexMod itself is not bundled.

## Disable, logs and removal

Set `Enabled` to `false` in `DS2SeamlessTextures.json` to bypass the texture handoff. Logs are under `%LOCALAPPDATA%\Rama2120\DS2SeamlessTextures`. `INJECTION_ATTEMPTED` confirms only that TexMod Run was invoked; `INJECTION_VERIFIED` names a texture whose replacement pixels matched in the running game.

For manual removal, close the game and remove only this mod's `version.dll`, `DS2TextureLauncher.exe`, `DS2SeamlessTextures.json` and `DS2STC-docs`, after checking the included manifest. Do not remove TexMod, texture packs, other proxy DLLs, game files or saves. With Vortex, disable and purge this mod through Vortex. Complete live uninstall recovery is pending beta testing.

The ZIP includes the project MIT license and MinHook attribution. A separate source ZIP is available. TexMod, Return to Titan, MarkerPatch, dgVoodoo, ReShade, REST and Conduit assets are not redistributed. No public source repository is claimed.
