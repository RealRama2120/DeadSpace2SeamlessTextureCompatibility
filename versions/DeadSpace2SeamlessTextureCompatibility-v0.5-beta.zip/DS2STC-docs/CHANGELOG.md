# Changelog

## 0.5.0-beta — 2026-09-24

- Carried forward the candidate's normal Steam Play evidence: all ten Return to Titan packs selected, menu rendering, save visibility, and normal exit on the tested installation. The newly labeled build has not been relaunched in-game.
- Replaced the live-test guardian's restrictive save locks with verified, closed backup copies; ordinary and mod-enabled save-menu checks now both show the existing save.
- Added a no-pack test phase for later acceptance and repaired portable ZIP paths and Windows PowerShell packaging.
- Labeled the release beta because Return to Titan gameplay replacement, extended stability, Vortex UI deployment, overlay behavior, and full uninstall recovery remain unverified.

## 0.1.0-candidate — 2026-09-23

- Introduced the standalone DS2 version proxy and automatic TexMod companion.
- Added per-launch package discovery, Vortex file-symlink support, content validation, priorities, exact disables and duplicate handling.
- Added exact-content Return to Titan order and superseded-package profiles without bundling texture content.
- Added consent-based HTTPS acquisition with pinned original TexMod checksums.
- Added executable selection and package-list readback, runtime replacement evidence and visible failure reporting.
- Added isolated package/native/graphics tests and reversible full-stack live-test tooling.
- Validation is ongoing. Consult TEST-REPORT before any public release.
