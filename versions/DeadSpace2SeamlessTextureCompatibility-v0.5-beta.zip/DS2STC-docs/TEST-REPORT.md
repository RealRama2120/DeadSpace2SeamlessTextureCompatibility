# v0.5 beta validation report

The underlying candidate was tested on one Windows installation of the Steam edition of the original 32-bit Dead Space 2. The v0.5 beta changes the version label and packaging; its compiled launcher has passed isolated and package checks but has not been relaunched in the game. Results below distinguish actual candidate game behavior from isolated and package checks. No second device or EA/Origin edition was tested.

## Confirmed in the game

- Normal Steam Play started the texture launcher and a single rendered TexMod game child without renaming the executable or adding a Steam launch option.
- A controlled diagnostic replacement visibly changed a title-menu texture. Its bound pixels matched the expected replacement in the runtime observer. This proves one encountered game texture, not general gameplay coverage.
- All ten current Return to Titan packs were selected in the intended order and the altered title and main menu appeared. Selection and title appearance do not prove that every pack replaced gameplay textures.
- The existing save was visible under Single Player in both an ordinary Steam launch and a mod-enabled ten-pack launch. It was not loaded or progressed. Both sessions ended through Exit Game. The guarded comparisons found the protected save, settings, game executable and existing graphics/mod files unchanged.
- The tested rendered process loaded the new version proxy alongside MarkerPatch, dgVoodoo, ReShade and REST modules. Their complete feature behavior was not individually exercised.

## Isolated checks

- Twenty managed checks passed for discovery, validation, ordering, disabled packs, duplicates, corruption, paths with spaces or Unicode, and bounded log handling.
- Five native harness checks passed for bypass, handoff, failure, recursion protection and proxy removal. These are simulated host checks, not game runs.
- A controlled graphics host showed the top TexMod list row winning a deliberate collision with and without dgVoodoo. A Return to Titan collision winner has not yet been seen in gameplay.
- The archive generator verifies entry names, lengths and SHA-256 values. The install ZIP contains no TexMod executable, Return to Titan pack, game binary, other graphics mod, save or private test evidence. The Vortex installer mapping can place its entries at the game root, but live Vortex UI deployment is untested.

## Open beta limits

The latest ten-pack menu run reported zero pixel-verified Return to Titan targets. The only observed target was unsupported or ambiguous for the current pixel comparison. It was not a demonstrated replacement failure, but gameplay injection remains unverified. Representative scenes, collision outcomes, longer sessions, 32-bit memory capacity, Steam overlay/input in the rendered child, repeated launches, no-pack and disabled launches, live Vortex deployment/purge, and full uninstall recovery remain to be tested. A prepared no-pack live test was cancelled before Steam Play; it says nothing about that behavior.

An earlier test guardian held the live save with restrictive sharing while the save did not appear in the modded menu. The guardian now creates verified backup copies and closes those handles before launch. The save appeared in both ordinary and modded no-lock sessions. The original cause was not directly traced, so the file-sharing explanation remains a hypothesis.

This evidence supports a v0.5 beta for further testing. It does not support a stable v1.0 claim or universal texture-pack compatibility.
