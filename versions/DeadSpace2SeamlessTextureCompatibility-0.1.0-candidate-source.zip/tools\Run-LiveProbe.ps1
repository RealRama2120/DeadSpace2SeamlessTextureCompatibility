param([switch]$Approved,[int]$Seconds=240)
$ErrorActionPreference='Stop'
if(-not $Approved){throw 'User approval is required for the temporary live probe.'}
$project=Split-Path -Parent $PSScriptRoot
$live='E:\SteamLibrary\steamapps\common\Dead Space 2'
$plugins=Join-Path $live 'plugins'
$target=Join-Path $plugins 'DS2SeamlessTextures.asi'
$log=Join-Path $live 'DS2STC-probe.log'
$source=Join-Path $project 'build\DS2SeamlessTextures.asi'
if(Get-Process -Name deadspace2 -ErrorAction SilentlyContinue){throw 'Game already running'}
if((Test-Path -LiteralPath $target) -or (Test-Path -LiteralPath $log)){throw 'Probe path occupied; refusing overwrite'}
$createdDirectory=-not(Test-Path -LiteralPath $plugins)
$guards=@();$installed=$false;$before=@();$seen=$false;$ownedId=0
try {
    foreach($folder in @('C:\Users\flask\Documents\EA Games\Dead Space 2','C:\Users\flask\AppData\Local\EA Games\Dead Space 2')) {
        foreach($file in Get-ChildItem -LiteralPath $folder -File) {
            $before += [pscustomobject]@{path=$file.FullName;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash}
            Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $project ('private-test\live-probe-backup-'+$file.Name)) -Force
            $guards += [IO.File]::Open($file.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        }
    }
    foreach($name in @('MarkerPatch.ini','dgVoodoo.conf','ReShade.ini','ReshadeEffectShaderToggler.ini','default.ini')) {
        $file=Join-Path $live $name
        Copy-Item -LiteralPath $file -Destination (Join-Path $project ('private-test\live-probe-backup-'+$name)) -Force
        $before += [pscustomobject]@{path=$file;sha256=(Get-FileHash -LiteralPath $file).Hash}
        $guards += [IO.File]::Open($file,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    }
    New-Item -ItemType Directory -Force -Path $plugins | Out-Null
    Copy-Item -LiteralPath $source -Destination $target
    $installed=$true;$installedHash=(Get-FileHash -LiteralPath $target).Hash
    $before | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $project 'evidence\live-probe-before.json')
    Write-Output 'Probe installed. Start Dead Space 2 with the ordinary Steam Play button; do not load a save.'
    $deadline=[DateTime]::UtcNow.AddSeconds($Seconds)
    while([DateTime]::UtcNow -lt $deadline) {
        $running=@(Get-Process -Name deadspace2 -ErrorAction SilentlyContinue)
        if($running.Count -eq 1) {
            if($running[0].Path -ne (Join-Path $live 'deadspace2.exe')){throw 'Unexpected game process path'}
            $seen=$true;$ownedId=$running[0].Id
            if(Test-Path -LiteralPath $log){$running[0].Modules | Select-Object ModuleName,FileName,BaseAddress,ModuleMemorySize | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $project 'evidence\live-probe-modules.json')}
        }
        if($seen -and $running.Count -eq 0){break}
        Start-Sleep -Seconds 2
    }
}finally {
    if($ownedId) {
        $owned=Get-Process -Id $ownedId -ErrorAction SilentlyContinue
        if($owned -and $owned.Path -eq (Join-Path $live 'deadspace2.exe')) {
            [void]$owned.CloseMainWindow()
            if(-not $owned.WaitForExit(5000)){$owned.Kill();$owned.WaitForExit()}
        }
    }
    foreach($guard in $guards){$guard.Dispose()}
    if($installed -and (Test-Path -LiteralPath $target)) {
        if((Get-FileHash -LiteralPath $target).Hash -ne $installedHash){throw 'Probe changed externally; retaining for review'}
        Remove-Item -LiteralPath $target
    }
    if(Test-Path -LiteralPath $log) {
        Copy-Item -LiteralPath $log -Destination (Join-Path $project 'evidence\live-probe.log') -Force
        Remove-Item -LiteralPath $log
    }
    if($createdDirectory -and (Test-Path -LiteralPath $plugins) -and @(Get-ChildItem -LiteralPath $plugins -Force).Count -eq 0){[IO.Directory]::Delete($plugins,$false)}
    @($before | ForEach-Object {[pscustomobject]@{path=$_.path;unchanged=($_.sha256 -eq (Get-FileHash -LiteralPath $_.path).Hash)}}) | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $project 'evidence\live-probe-after.json')
    Write-Output 'Temporary probe removed. Original files retained and verified.'
}
