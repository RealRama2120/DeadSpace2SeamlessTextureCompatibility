$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$live='E:\SteamLibrary\steamapps\common\Dead Space 2'
$copy=Join-Path $project 'private-test\game'
if (Test-Path -LiteralPath $copy) {throw 'Isolated copy already exists; refusing to overwrite.'}
New-Item -ItemType Directory -Path $copy | Out-Null
$hashes=@()
foreach($item in Get-ChildItem -LiteralPath $live -File) {
    if($item.Name -eq 'vortex.deployment.json') {continue}
    $dest=Join-Path $copy $item.Name
    # Resolve deployment symlinks by reading bytes, never copy shared links.
    $input=[IO.File]::OpenRead($item.FullName)
    try {$output=[IO.File]::Create($dest);try {$input.CopyTo($output)}finally{$output.Dispose()}}finally{$input.Dispose()}
    $hashes += [pscustomobject]@{name=$item.Name;sha256=(Get-FileHash -LiteralPath $dest).Hash;bytes=(Get-Item -LiteralPath $dest).Length}
}
foreach($folder in @('movies','reshade-shaders','achievements','plugins','mods')) {
    $source=Join-Path $live $folder
    if(Test-Path -LiteralPath $source) {Copy-Item -LiteralPath $source -Destination (Join-Path $copy $folder) -Recurse}
}
$hashes | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $project 'evidence\live-root-baseline.json')
Copy-Item -LiteralPath (Join-Path $live 'MarkerPatch.ini') -Destination (Join-Path $project 'evidence\MarkerPatch.original.ini')
Copy-Item -LiteralPath (Join-Path $live 'default.ini') -Destination (Join-Path $project 'evidence\autoloader.original.ini')
$inventory=Get-Content -LiteralPath (Join-Path $project 'evidence\audit-package-inventory.json') -Raw | ConvertFrom-Json
$rtt=Join-Path $project 'private-test\ReturnToTitan-complete\TexMod Packages'
New-Item -ItemType Directory -Path $rtt -Force | Out-Null
foreach($pack in $inventory | Where-Object set_status -eq 'author_current') {
    if((Get-FileHash -LiteralPath $pack.source_path).Hash -ne $pack.package_sha256) {throw ('Source package changed: '+$pack.package)}
    Copy-Item -LiteralPath $pack.source_path -Destination (Join-Path $rtt $pack.package)
}
$extension='C:\Users\flask\AppData\Roaming\Vortex\plugins\dead-space-2-vortex-extension-0.1.0\index.js'
Get-FileHash -LiteralPath $extension | Select-Object Path,Hash | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $project 'evidence\extension-baseline.json')
Write-Output 'Independent game copy and ten verified RTT packages prepared; live installation unchanged.'
