# Temporary Steam bootstrap timing test

Approval scope: add only `plugins/DS2SeamlessTextures.asi` and its new `DS2STC-probe.log` to the registered Dead Space 2 installation. No launcher or textures are installed during this test. The compiled probe records when MarkerPatch loads it, when the game next closes a registry key, and when it calls Direct3DCreate9. It changes two import pointers in the running process only; it does not inject TexMod or relaunch the game.

Run with the ordinary Steam Play button. Observe startup/main menu only. Existing saves and gameplay settings are backed up and held read-only. Existing MarkerPatch, dgVoodoo, ReShade, REST and autoloader configurations are backed up and held read-only. Existing game executable, graphics DLLs and packages are never replaced.

`tools/Run-LiveProbe.ps1 -Approved` owns the temporary files. After game exit, or four minutes, it closes the test game, removes only the matching probe, copies the probe log into project evidence and removes the live log. It removes the plugins directory only if the test created it and it remains empty. It verifies all protected configuration/save hashes. An externally changed probe is retained for review rather than deleted.

Manual recovery after a power loss: close DS2, compare the live probe hash with `build/DS2SeamlessTextures.asi`, remove that matching ASI and `DS2STC-probe.log`; leave every other plugin and all shared DLLs. No original configuration needs restoration because this probe does not edit them.

Reason for this test: the independent game copy failed with Steam error `5:0000065434` before ASI initialization. That is a test-environment blocker, not evidence that transparent TexMod launching is impossible.
