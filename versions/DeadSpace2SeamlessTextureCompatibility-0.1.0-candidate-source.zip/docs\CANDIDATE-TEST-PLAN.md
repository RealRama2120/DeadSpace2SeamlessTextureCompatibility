# Temporary complete-stack tests requiring approval

Add only these new paths to the registered Steam game directory: `version.dll`, `DS2TextureLauncher.exe`, `DS2SeamlessTextures.json`, and `DS2STC-test-packages/`. Refuse to overwrite any existing file at these paths. Leave MarkerPatch's DINPUT8.dll, dgVoodoo's D3D9.dll, ReShade's DXGI.dll, REST, Conduit restoration, the game EXE and all existing texture packages intact.

The new version.dll forwards the Windows version API, then intercepts the executable entry point in memory. The original Steam-tracked process waits for its companion; TexMod's child inherits a flag that bypasses the bootstrap. The executable on disk is never renamed or patched. Five native harness checks pass (forwarding/bypass, handoff, error return, recursion bypass, uninstall), but an actual Steam test remains necessary.

Test sequence: single diagnostic package; both diagnostic packages with reversed requested priority; full ten-package RTT set; repeat launch; disabled candidate; candidate removed and ordinary original launch. Save files and gameplay settings remain backed up and locked against writes. Loading a save for observation is allowed only under the approved test scope, and no save operation is performed. UI configuration and graphics settings are not changed. Runtime-only logs, screenshots and process/memory evidence are recorded.

The launcher currently reports injection as UNVERIFIED until a controlled replacement comparison proves it. A successful TexMod list or game window is not acceptance. Empirical TexMod winning priority, complete pack capacity, overlay behavior and gameplay stability are still open. Release/publishing remain prohibited until acceptance.

`tools/Run-CandidateTest.ps1 -Approved -Phase diagnostic` installs a temporary session, records every added file's hash, captures process/module/memory evidence, and removes only those exact files on exit or timeout. Use priority, priority-reversed, rtt and disabled phases for later tests. Every existing configuration is backed up and read-locked; rollback compares saved hashes. If an added file changes externally, the script preserves it for review.

Power-loss recovery: close the game and texture launcher; consult the latest candidate evidence directory's owned-files.json. Remove only listed files whose SHA-256 still matches. Never remove shared graphics DLLs or existing TPFs. Retain all unrelated contents of the test directory. Logs under LocalAppData/Rama2120/DS2SeamlessTextures can remain for diagnosis.
