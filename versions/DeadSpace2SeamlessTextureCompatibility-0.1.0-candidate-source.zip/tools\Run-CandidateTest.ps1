param([switch]$Approved,[ValidateSet('diagnostic','priority','priority-reversed','rtt','disabled','baseline')][string]$Phase='diagnostic',[int]$Seconds=600)
$ErrorActionPreference='Stop'
if(-not $Approved){throw 'Explicit user approval is required for temporary live candidate installation.'}
$project=Split-Path -Parent $PSScriptRoot
$live='E:\SteamLibrary\steamapps\common\Dead Space 2'
$run=Join-Path $project ('evidence\candidate-'+$Phase+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $run | Out-Null
$newFiles=@('version.dll','DS2TextureLauncher.exe','DS2SeamlessTextures.json')
$packRoot=Join-Path $live 'DS2STC-test-packages'
foreach($file in $newFiles){if(Test-Path -LiteralPath (Join-Path $live $file)){throw ('Occupied destination: '+$file)}}
if(Test-Path -LiteralPath $packRoot){throw 'Test package destination already exists'}
if(Get-Process -Name deadspace2,DS2TextureLauncher,Texmod -ErrorAction SilentlyContinue){throw 'Existing game or texture utility is running'}
$owned=@();$guards=@();$before=@();$seen=$false;$tracked=@{};$memory=@();$forced=@();$started=[DateTime]::UtcNow;$endReason='exception'
function Add-OwnedFile([string]$Source,[string]$Destination) {
    if(Test-Path -LiteralPath $Destination){throw ('Refusing overwrite: '+$Destination)}
    Copy-Item -LiteralPath $Source -Destination $Destination
    $script:owned += [pscustomobject]@{path=$Destination;sha256=(Get-FileHash -LiteralPath $Destination).Hash}
}
try {
    foreach($folder in @('C:\Users\flask\Documents\EA Games\Dead Space 2','C:\Users\flask\AppData\Local\EA Games\Dead Space 2')) {
        foreach($file in Get-ChildItem -LiteralPath $folder -File) {
            Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $run $file.Name)
            $before += [pscustomobject]@{path=$file.FullName;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash}
            $guards += [IO.File]::Open($file.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        }
    }
    foreach($name in @('MarkerPatch.ini','dgVoodoo.conf','ReShade.ini','ReshadeEffectShaderToggler.ini','default.ini')) {
        $file=Join-Path $live $name;Copy-Item -LiteralPath $file -Destination (Join-Path $run $name)
        $before += [pscustomobject]@{path=$file;sha256=(Get-FileHash -LiteralPath $file).Hash}
        $guards += [IO.File]::Open($file,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    }
    foreach($name in @('deadspace2.exe','dinput8.dll','D3D9.dll','dxgi.dll','DS2DAT0_CONDUIT4PC.DAT')) {
        $file=Join-Path $live $name;$before += [pscustomobject]@{path=$file;sha256=(Get-FileHash -LiteralPath $file).Hash}
    }
    if($Phase -ne 'baseline') {
    Add-OwnedFile (Join-Path $project 'build\version.dll') (Join-Path $live 'version.dll')
    Add-OwnedFile (Join-Path $project 'build\DS2TextureLauncher.exe') (Join-Path $live 'DS2TextureLauncher.exe')
    New-Item -ItemType Directory -Path $packRoot | Out-Null
    $test=(Get-Content -LiteralPath (Join-Path $project 'evidence\latest-test-root.txt')).Trim()
    if($Phase -eq 'rtt') {
        foreach($pack in Get-ChildItem -LiteralPath (Join-Path $project 'private-test\ReturnToTitan-complete\TexMod Packages') -Filter *.tpf){Add-OwnedFile $pack.FullName (Join-Path $packRoot $pack.Name)}
    }else {
        Add-OwnedFile (Join-Path $test 'diagnostic-packages\Diagnostic-Magenta.tpf') (Join-Path $packRoot 'Diagnostic-Magenta.tpf')
        if($Phase -like 'priority*'){Add-OwnedFile (Join-Path $test 'diagnostic-packages\Diagnostic-Cyan.tpf') (Join-Path $packRoot 'Diagnostic-Cyan.tpf')}
    }
    $settings=Get-Content -LiteralPath (Join-Path $project 'DS2SeamlessTextures.json') -Raw | ConvertFrom-Json
    $settings.Enabled=$Phase -ne 'disabled';$settings.PackageFolders=@('DS2STC-test-packages');$settings.ShowTexMod=$false
    $settings | Add-Member -NotePropertyName TraceTextures -NotePropertyValue $false -Force
    if($Phase -like 'priority*'){$settings.Priority=[pscustomobject]@{'DS2STC-test-packages/Diagnostic-Magenta.tpf'=$(if($Phase -eq 'priority'){100}else{-100})}}
    $config=Join-Path $run 'candidate-settings.json';$settings | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $config
    Add-OwnedFile $config (Join-Path $live 'DS2SeamlessTextures.json')
    }
    $owned | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $run 'owned-files.json')
    $before | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $run 'before.json')
    Write-Output ('Candidate ready for normal Steam Play. Phase='+$Phase+' Evidence='+$run)
    $deadline=[DateTime]::UtcNow.AddSeconds($Seconds)
    while([DateTime]::UtcNow -lt $deadline -and -not(Test-Path -LiteralPath (Join-Path $run 'stop.request'))) {
        $games=@(Get-Process -Name deadspace2 -ErrorAction SilentlyContinue)
        foreach($game in $games) {
            if($game.Path -ne (Join-Path $live 'deadspace2.exe')){throw 'Unexpected game path'}
            $seen=$true;$tracked[[string]$game.Id]=$game.StartTime.ToUniversalTime().Ticks
            $memory += [pscustomobject]@{utc=[DateTime]::UtcNow.ToString('o');pid=$game.Id;private_bytes=$game.PrivateMemorySize64;working_set=$game.WorkingSet64}
            $game.Modules | Select-Object ModuleName,FileName,BaseAddress,ModuleMemorySize | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $run ('modules-'+$game.Id+'.json'))
        }
        foreach($name in @('DS2TextureLauncher','Texmod')) {
            foreach($proc in Get-Process -Name $name -ErrorAction SilentlyContinue) {
                if($proc.Path -in @((Join-Path $live 'DS2TextureLauncher.exe'),(Join-Path $live 'Texmod.exe'))) {$tracked[[string]$proc.Id]=$proc.StartTime.ToUniversalTime().Ticks;$memory += [pscustomobject]@{utc=[DateTime]::UtcNow.ToString('o');pid=$proc.Id;private_bytes=$proc.PrivateMemorySize64;working_set=$proc.WorkingSet64}}
            }
        }
        if($seen -and $games.Count -eq 0){$endReason='game-processes-ended';break}
        Start-Sleep -Seconds 2
    }
    if($endReason -eq 'exception'){$endReason=$(if(Test-Path -LiteralPath (Join-Path $run 'stop.request')){'stop-request'}else{'deadline'})}
}finally {
    foreach($id in $tracked.Keys) {
        $proc=Get-Process -Id ([int]$id) -ErrorAction SilentlyContinue
        if($proc -and $proc.StartTime.ToUniversalTime().Ticks -eq $tracked[$id] -and $proc.Path -in @((Join-Path $live 'deadspace2.exe'),(Join-Path $live 'DS2TextureLauncher.exe'),(Join-Path $live 'Texmod.exe'))) {
            $forced += [pscustomobject]@{pid=$proc.Id;name=$proc.ProcessName;action='cleanup-close'}
            [void]$proc.CloseMainWindow();if(-not $proc.WaitForExit(3000)){$forced[-1].action='cleanup-kill';$proc.Kill();$proc.WaitForExit()}
        }
    }
    foreach($guard in $guards){$guard.Dispose()}
    foreach($file in $owned) {
        if(Test-Path -LiteralPath $file.path){if((Get-FileHash -LiteralPath $file.path).Hash -ne $file.sha256){throw ('Owned file changed; retaining for review: '+$file.path)};Remove-Item -LiteralPath $file.path}
    }
    if((Test-Path -LiteralPath $packRoot) -and @(Get-ChildItem -LiteralPath $packRoot -Force).Count -eq 0){[IO.Directory]::Delete($packRoot,$false)}
    @($before | ForEach-Object {[pscustomobject]@{path=$_.path;unchanged=($_.sha256 -eq (Get-FileHash -LiteralPath $_.path).Hash)}}) | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $run 'after.json')
    $memory | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $run 'memory.json')
    $logs=Join-Path $env:LOCALAPPDATA 'Rama2120\DS2SeamlessTextures'
    foreach($name in @('latest.log','bootstrap.log','packages.json')){if(Test-Path -LiteralPath (Join-Path $logs $name)){Copy-Item -LiteralPath (Join-Path $logs $name) -Destination (Join-Path $run $name)}}
    if(Test-Path -LiteralPath (Join-Path $logs 'sessions')) {
        foreach($session in Get-ChildItem -LiteralPath (Join-Path $logs 'sessions') -Directory | Where-Object {$_.CreationTimeUtc -ge $started}) {
            $destination=Join-Path $run $session.Name;New-Item -ItemType Directory -Path $destination | Out-Null
            foreach($name in @('runtime.log','expected.txt')){if(Test-Path -LiteralPath (Join-Path $session.FullName $name)){Copy-Item -LiteralPath (Join-Path $session.FullName $name) -Destination $destination}}
        }
    }
    [pscustomobject]@{reason=$endReason;cleanup_processes=$forced;started_utc=$started.ToString('o');ended_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $run 'shutdown.json')
    Write-Output 'Candidate removed; original-file comparisons saved.'
}
