param([int]$Seconds=180)
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$game=Join-Path $project 'private-test\game'
if(Get-Process -Name deadspace2 -ErrorAction SilentlyContinue){throw 'Close the existing game before isolated testing.'}
New-Item -ItemType Directory -Force -Path (Join-Path $game 'plugins') | Out-Null
Copy-Item -LiteralPath (Join-Path $project 'build\DS2SeamlessTextures.asi') -Destination (Join-Path $game 'plugins\DS2SeamlessTextures.asi') -Force
$guards=@();$before=@();$proc=$null
try {
    foreach($folder in @('C:\Users\flask\Documents\EA Games\Dead Space 2','C:\Users\flask\AppData\Local\EA Games\Dead Space 2')) {
        foreach($file in Get-ChildItem -LiteralPath $folder -File) {
            $before += [pscustomobject]@{path=$file.FullName;sha256=(Get-FileHash -LiteralPath $file.FullName).Hash}
            Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $project ('private-test\backup-'+$file.Name)) -Force
            $guards += [IO.File]::Open($file.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        }
    }
    $before | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $project 'evidence\probe-save-settings-before.json')
    $proc=Start-Process -FilePath (Join-Path $game 'deadspace2.exe') -WorkingDirectory $game -PassThru
    Write-Output ('Isolated actual-game probe PID='+$proc.Id)
    $deadline=[DateTime]::UtcNow.AddSeconds($Seconds)
    $captured=$false
    while(-not $proc.HasExited -and [DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Seconds 2
        $proc.Refresh()
        if(-not $captured -and -not $proc.HasExited -and $proc.WorkingSet64 -gt 120MB) {
            $proc.Modules | Select-Object ModuleName,FileName,BaseAddress,ModuleMemorySize | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $project 'evidence\probe-modules.json')
            $captured=$true
        }
    }
}finally {
    if($proc -and -not $proc.HasExited) {
        [void]$proc.CloseMainWindow()
        if(-not $proc.WaitForExit(5000)) {
            if($proc.MainModule.FileName -ne (Join-Path $game 'deadspace2.exe')) {throw 'Process identity changed; refusing termination'}
            $proc.Kill();$proc.WaitForExit()
        }
    }
    foreach($guard in $guards){$guard.Dispose()}
    @($before | ForEach-Object {[pscustomobject]@{path=$_.path;unchanged=($_.sha256 -eq (Get-FileHash -LiteralPath $_.path).Hash)}}) | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $project 'evidence\probe-save-settings-after.json')
}
