# v0.5.1 beta validation report

This report separates the user's v0.5.0 gameplay test from checks of the corrected v0.5.1 build. Testing used one Windows installation of the Steam edition of the original 32-bit Dead Space 2. The v0.5.1 binary has **not** been relaunched in the game. No EA/Origin edition or second device was tested.

## What worked in the game

- Normal Steam Play started the texture launcher and the rendered TexMod game process without a renamed game executable or Steam launch option.
- An earlier controlled diagnostic replacement visibly changed a title-menu texture, and the runtime observer matched its bound pixels. This demonstrates one real replacement, not general gameplay coverage.
- Earlier guarded runs selected all ten audited Return to Titan packs, reached the altered title and main menu, showed the existing save in a mod-enabled launch, and ended through normal Exit Game. Protected save, settings, executable and existing graphics/mod files matched their pre-run hashes in those guarded checks.
- In the user's later v0.5.0 beta test, Steam Play and startup worked. The existing save appeared; approximately 25 minutes of gameplay, save/reload, controls, ReShade, normal exit/reopen, and Vortex disable/re-enable/deploy were user-reported working. No missing or flickering textures were seen. These were not guarded file-hash or Vortex purge checks.
- The user thought several textures, including the shop station, looked improved, but could not capture comparison screenshots. This observation alone does not identify the supplying pack.

## Eight-pack discovery and runtime warning

The user's session `packages.json` and `latest.log` selected **eight of the ten** audited Return to Titan packages: `1WEP_RTTn.tpf` and interactable packs `3INTERACTABLES_RTTn.tpf` through `9INTERACTABLES_RTT.tpf`. The suit pack `1-4KMainSuitsnew.tpf` and AIO pack `2Kaio.tpf` were absent from the deployed game-folder package links and selected list. They exist in verified private staging but were not deployed in this session. The release includes no Return to Titan packs.

The runtime observer reported `verified_hashes=0` and `failed_hashes=53` under the v0.5.0 terminology. Fifty-three targets bound a different readable texture object whose pixel CRC did not exactly match the selected TPF payload. Fifty-two of those bound objects had larger dimensions than their mapped original game textures. Examples: wall corner `0E35DF28`, pulse-rifle color `EE143D9E`, and save-station housing `32BFECEB` map to 512×512 originals and appeared as 1024×1024 bound objects. One encountered target was unreadable and four were unsupported or ambiguous for the pixel comparison. The high-resolution objects strongly support gameplay texture substitution, but do **not** prove exact Return to Titan artwork or identify why pixel CRCs differed. Possible causes remain unisolated.

The v0.5.0 popup said texture injection had failed for at least one target. That conclusion exceeded the evidence. v0.5.1 changes the event to `INJECTION_PIXEL_MISMATCH` for a different readable object and explains that exact package pixels are unverified. It also writes `RETURN_TO_TITAN selected=N/10` with missing audited pack names. These reporting changes do not repair or establish any texture replacement, and require an in-game retest.

## Open compatibility findings

Shift+Tab did not open the Steam overlay in the user's modded session. An earlier rendered TexMod child did not show the overlay module that appeared in an ordinary Steam process. An interactive unmodded Shift+Tab baseline has not been performed, so the cause remains unresolved. Alt+Tab had a problem that the user has also observed without TexMod; attribution remains unresolved. Save/reload passed by user report, with no independent post-session save hash for this gameplay run.

Full ten-pack gameplay, representative before/after captures, runtime collision winners, longer-session and memory headroom, Steam overlay support, first-run TexMod acquisition on another machine, complete Vortex purge and uninstall recovery, and EA/Origin support remain unverified. The earlier guarded ten-pack test reached the menu; it was not this gameplay test.

## v0.5.1 build checks

The managed test suite passed 22 checks, including partial Return to Titan inventory reporting. Five native host checks passed. A fresh isolated graphics check was inconclusive on this desktop: the system backend could not create a device and the dgVoodoo host timed out; its test-owned processes were stopped. Earlier controlled graphics checks passed on this machine, but they do not validate the rebuilt v0.5.1 observer. Packaging verifies each archive entry's path, size and SHA-256. The install ZIP contains no TexMod executable, Return to Titan pack, game binary, other graphics mod or save. Offline checks do not substitute for a v0.5.1 in-game run.

This evidence supports a beta for further testing, not a stable v1.0 claim.
