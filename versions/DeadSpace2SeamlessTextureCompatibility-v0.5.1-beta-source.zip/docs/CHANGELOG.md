# Changelog

## 0.5.1-beta — 2026-09-24

- Corrected the runtime observer's wording: an exact-pixel mismatch in a different bound texture object is now reported as `INJECTION_PIXEL_MISMATCH`, not proof that texture injection failed.
- Added an exact-content Return to Titan pack count and missing-pack names to `latest.log` when any audited packs are selected.
- Recorded the first user gameplay session: eight packs were deployed, 52 of 53 mismatched targets bound at higher resolution than their mapped game originals, approximately 25 minutes of stable play, save/reload, and Vortex disable/re-enable. Steam overlay did not open and remains unresolved.
- No texture packs or third-party game/mod files are bundled. The corrected runtime needs a new in-game retest before stronger claims.

## 0.5.0-beta — 2026-09-24

- Carried forward the candidate's normal Steam Play evidence: all ten Return to Titan packs selected, menu rendering, save visibility, and normal exit on the tested installation. The newly labeled build has not been relaunched in-game.
- Replaced the live-test guardian's restrictive save locks with verified, closed backup copies; ordinary and mod-enabled save-menu checks now both show the existing save.
- Added a no-pack test phase for later acceptance and repaired portable ZIP paths and Windows PowerShell packaging.
- Labeled the release beta because Return to Titan gameplay replacement, extended stability, Vortex UI deployment, overlay behavior, and full uninstall recovery remain unverified.

## 0.1.0-candidate — 2026-09-23

- Introduced the standalone DS2 version proxy and automatic TexMod companion.
- Added per-launch package discovery, Vortex file-symlink support, content validation, priorities, exact disables and duplicate handling.
- Added exact-content Return to Titan order and superseded-package profiles without bundling texture content.
- Added consent-based HTTPS acquisition with pinned original TexMod checksums.
- Added executable selection and package-list readback, runtime replacement evidence and visible failure reporting.
- Added isolated package/native/graphics tests and reversible full-stack live-test tooling.
- Validation is ongoing. Consult TEST-REPORT before any public release.
