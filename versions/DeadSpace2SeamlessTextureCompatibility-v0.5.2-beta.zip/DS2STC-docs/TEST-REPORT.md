# v0.5.2 beta validation report

This report separates user gameplay tests of v0.5.0 and v0.5.1 from offline checks of v0.5.2. Testing used one Windows installation of the Steam edition of the original 32-bit Dead Space 2. The v0.5.2 binary has **not** been relaunched in the game. No EA/Origin edition or second device was tested.

## What worked in the game

- Normal Steam Play started the texture launcher and the rendered TexMod game process without a renamed game executable or Steam launch option.
- An earlier controlled diagnostic replacement visibly changed a title-menu texture, and the runtime observer matched its bound pixels. This demonstrates one real replacement, not general gameplay coverage.
- Earlier guarded runs selected all ten audited Return to Titan packs, reached the altered title and main menu, showed the existing save in a mod-enabled launch, and ended through normal Exit Game. Protected save, settings, executable and existing graphics/mod files matched their pre-run hashes in those guarded checks.
- In the user's later v0.5.0 beta test, Steam Play and startup worked. The existing save appeared; approximately 25 minutes of gameplay, save/reload, controls, ReShade, normal exit/reopen, and Vortex disable/re-enable/deploy were user-reported working. No missing or flickering textures were seen. These were not guarded file-hash or Vortex purge checks.
- The user thought several textures, including the shop station, looked improved, but could not capture comparison screenshots. This observation alone does not identify the supplying pack.

## Eight-pack discovery and runtime warning

The user's session `packages.json` and `latest.log` selected **eight of the ten** audited Return to Titan packages: `1WEP_RTTn.tpf` and interactable packs `3INTERACTABLES_RTTn.tpf` through `9INTERACTABLES_RTT.tpf`. The suit pack `1-4KMainSuitsnew.tpf` and AIO pack `2Kaio.tpf` were absent from the deployed game-folder package links and selected list. They exist in verified private staging but were not deployed in this session. The release includes no Return to Titan packs.

The runtime observer reported `verified_hashes=0` and `failed_hashes=53` under the v0.5.0 terminology. Fifty-three targets bound a different readable texture object whose pixel CRC did not exactly match the selected TPF payload. Fifty-two of those bound objects had larger dimensions than their mapped original game textures. Examples: wall corner `0E35DF28`, pulse-rifle color `EE143D9E`, and save-station housing `32BFECEB` map to 512×512 originals and appeared as 1024×1024 bound objects. One encountered target was unreadable and four were unsupported or ambiguous for the pixel comparison. The high-resolution objects strongly support gameplay texture substitution, but do **not** prove exact Return to Titan artwork or identify why pixel CRCs differed. Possible causes remain unisolated.

The v0.5.0 popup said texture injection had failed for at least one target. That conclusion exceeded the evidence. v0.5.1 changed the event to `INJECTION_PIXEL_MISMATCH` for a different readable object and explained that exact package pixels were unverified. It also added `RETURN_TO_TITAN selected=N/10` with missing audited pack names. The subsequent v0.5.1 gameplay retest appears below.

## Open compatibility findings

Shift+Tab did not open the Steam overlay in the user's modded session. An earlier rendered TexMod child did not show the overlay module that appeared in an ordinary Steam process. An interactive unmodded Shift+Tab baseline has not been performed, so the cause remains unresolved. Alt+Tab had a problem that the user has also observed without TexMod; attribution remains unresolved. Save/reload passed by user report, with no independent post-session save hash for this gameplay run.

Full ten-pack gameplay, representative before/after captures, runtime collision winners, longer-session and memory headroom, Steam overlay support, first-run TexMod acquisition on another machine, complete Vortex purge and uninstall recovery, and EA/Origin support remain unverified. The earlier guarded ten-pack test reached the menu; it was not this gameplay test.

## v0.5.1 pre-game build checks

The managed test suite passed 22 checks, including partial Return to Titan inventory reporting. Five native host checks passed. A fresh isolated graphics check was inconclusive on this desktop: the system backend could not create a device and the dgVoodoo host timed out; its test-owned processes were stopped. Earlier controlled graphics checks passed on this machine but did not validate the rebuilt v0.5.1 observer. Packaging verifies each archive entry's path, size and SHA-256. The install ZIP contains no TexMod executable, Return to Titan pack, game binary, other graphics mod or save.

## v0.5.1 full ten-pack gameplay and v0.5.2 diagnostic correction

In the user's next normal Steam Play run, `latest.log` reported `RETURN_TO_TITAN selected=10/10 missing=none` and listed all ten TexMod rows in the intended order. The runtime observer initialized in the rendered game child with 396 expected target hashes and hook status zero. The user reported smooth gameplay and perceived an improvement to suits, then closed the game normally. No game, TexMod or launcher process remained after close. This is the first user gameplay run with the complete ten-pack set, though it was not a long stress test.

The raw `runtime.log` contains 40 distinct `INJECTION_PIXEL_MISMATCH` events, seven unsupported or ambiguous targets, and zero `INJECTION_VERIFIED` events. All 40 readable mismatches bound a different texture object at the selected replacement's dimensions and format; all 40 were larger than the mapped original game texture. Fifteen target hashes belong to the selected dedicated suit pack, including player-head, engineering-suit and security-suit textures. Nine more were first supplied by the AIO pack. These measurements support the user's suit impression and high-resolution substitution in gameplay, but still do not establish exact package artwork. None of the 40 actual CRCs matched a payload CRC from another selected pack for the same target, so a simple collision-winner mix-up does not explain the pattern. The cause of the exact pixel differences remains unisolated.

The v0.5.1 warning dialog paused the launcher's log reader while gameplay continued. Its end-of-run summary therefore counted only four pixel mismatches, despite 40 in the raw runtime log. v0.5.2 logs inconclusive pixel mismatches without a modal dialog and drains the runtime log again after the game exits. That change corrects the diagnostic interruption and undercount; it does not alter the texture data or establish an exact match. The user again reported that Shift+Tab did not open Steam Overlay. The user recalls similar behavior without this mod, but no interactive unmodded baseline has been measured, so attribution remains open.

The v0.5.2 build and automated checks pass; its behavior in the actual game remains untested. Full-set extended gameplay, exact artwork verification, an in-game collision winner, the Steam overlay baseline, and complete uninstall recovery remain acceptance work for v1.0.

This evidence supports a beta for further testing, not a stable v1.0 claim.
