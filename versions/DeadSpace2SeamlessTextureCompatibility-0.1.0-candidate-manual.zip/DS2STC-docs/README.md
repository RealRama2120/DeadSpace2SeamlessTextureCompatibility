# Dead Space 2 Seamless Texture Compatibility

Version 0.1.0-candidate. Standalone normal-launch texture loader for the original 32-bit PC game. This is a validation candidate; see `docs/TEST-REPORT.md` for the measured scope and outstanding acceptance checks. Do not describe it as fully validated or publish it as a stable release yet.

The mod discovers compatible TexMod `.tpf` packs on each launch, validates their contents, and starts the original game through a verified TexMod installation. Your normal Steam Play button remains the entry point. No renamed game executable, custom Steam launch options, manual TexMod setup, or dependency on the Dead Space 2008 mod is required.

## Install

Close the game. Extract the manual archive beside `deadspace2.exe` and `DS2DAT0.DAT`. The three runtime files are `version.dll`, `DS2TextureLauncher.exe`, and `DS2SeamlessTextures.json`. Keep the documentation and license folder with them. If another mod already owns `version.dll`, stop: this candidate does not chain another version proxy. Never overwrite an existing proxy to resolve a conflict.

The Vortex archive has the same game-root layout. Install it using the separate Dead Space 2 game-support extension, enable it, and deploy. The extension is not bundled or modified. Actual Vortex UI deployment and purge are a separate validation item.

Install your texture packs separately, preferably inside `TexMod Packages` and its subfolders. The mod also checks game-root `.tpf` files, `TexturePacks`, and `Mods`. It follows Vortex file symlinks, skips directory junctions/symlinks, and ignores unrelated archives and Vortex metadata. No texture packs are included.

Launch through Steam normally. A trusted existing `Texmod.exe` in the game folder is reused. Otherwise, the first launch asks permission to download the original TexMod 0.9b from its archived project and checks pinned archive and executable hashes. Declining cancels the texture-enabled launch. Later launches are automatic.

## Compatibility and evidence

The new proxy occupies `version.dll`; it preserves MarkerPatch's `DINPUT8.dll`, dgVoodoo's `D3D9.dll`, and ReShade's `DXGI.dll`. Real-game testing has confirmed a diagnostic replacement with those modules and REST loaded. That single result does not establish complete Return to Titan coverage, gameplay stability, Steam overlay support, or other storefront compatibility. Consult the test report before use.

The original Steam-started process waits while one TexMod-started process renders the game. Two `deadspace2.exe` process entries are therefore expected during an enabled session; only one should render a game window. Closing the rendered game normally ends the companion and waiting parent. The Steam overlay in the rendered child remains a known validation concern.

## Configuration and troubleshooting

No configuration changes are required for ordinary use. See `docs/CONFIGURATION.md` for exact priorities, disabled packs, discovery folders and diagnostics.

Logs are in `%LOCALAPPDATA%\Rama2120\DS2SeamlessTextures`. Start with `latest.log` and `packages.json`; `sessions/<session>/runtime.log` records individual replacement results. `INJECTION_ATTEMPTED` only means TexMod Run was invoked. `INJECTION_VERIFIED` confirms the named encountered target's replacement pixels. Unencountered textures, cubemaps, unsupported image encodings and ambiguous internal entries remain unverified.

A corrupt or inaccessible selected pack stops the texture launch with an error. A measured replacement mismatch displays a warning and leaves the game running. Missing verification initialization also warns. Retain logs when reporting a problem; review local paths before sharing them.

## Disable or uninstall

To temporarily disable the mod, set `Enabled` to `false` in `DS2SeamlessTextures.json`, then launch normally. The original process continues without the TexMod handoff.

For a manual uninstall, close the game and remove only this mod's `version.dll`, `DS2TextureLauncher.exe`, `DS2SeamlessTextures.json`, and `DS2STC-docs` folder. Use the package manifest to identify them. If another tool changed one of these files, resolve ownership before removing it. For Vortex, disable this mod and deploy/purge through Vortex. Leave all texture packs, `Texmod.exe`, game files, saves, `DINPUT8.dll`, `D3D9.dll`, `DXGI.dll`, REST and Conduit files alone. Optional cached logs and the consent-downloaded TexMod copy live only inside the mod's LocalAppData folder.

Source and build instructions are included in the separate source archive. No public source repository is claimed. Original project code is MIT licensed; MinHook's bundled license also applies.
