# Dead Space 2 Seamless Texture Compatibility — 0.1.0 candidate

**Release status: private validation candidate. Do not publish this text as a stable compatibility claim until the test report's outstanding checks pass.**

Install compatible TexMod `.tpf` packs, then start the original PC Dead Space 2 through Steam Play. This standalone mod finds packs on every launch, validates them and hands the game to the original TexMod 0.9b automatically. No renamed `deadspace2.exe`, Steam launch option, separate launcher or routine TexMod setup is needed. Optional exact priority and disable rules are available for collisions.

The candidate coexists with the tested MarkerPatch `DINPUT8.dll`, dgVoodoo `D3D9.dll`, ReShade `DXGI.dll` and REST addon. A visible magenta diagnostic texture and pixel-level observer log confirm one real Dead Space 2 replacement through normal Steam Play. A separate run loaded all ten Return to Titan packs and reached the altered title and main menu. Gameplay appearance, complete pack coverage, Steam overlay, clean close/reopen and Vortex UI acceptance are still pending; see the included `DS2STC-docs/TEST-REPORT.md`.

## Installation

Close the game. For manual installation, extract the manual ZIP directly into the folder containing `deadspace2.exe` and `DS2DAT0.DAT`. For Vortex, use the separate Dead Space 2 game-support extension and install the Vortex ZIP; deploy it as a game-root mod. The archives contain exactly three runtime files plus a documentation folder. If `version.dll` already exists, resolve that ownership conflict before installation. Do not overwrite another mod's version proxy.

Install texture packs separately, such as in `TexMod Packages`. Root `.tpf` files and subfolders of `TexMod Packages`, `TexturePacks` and `Mods` are discovered on each launch, including Vortex's deployed file links. The loader never bundles texture packs. Exact known obsolete Return to Titan packages are excluded only when their verified replacements are available.

Launch through Steam normally. If a checksum-verified original `Texmod.exe` is already available, it is reused. Otherwise, the first launch asks consent to retrieve the original archived TexMod 0.9b over HTTPS and verifies pinned hashes. Later launches require no prompt.

## Disable, logs and uninstall

Set `Enabled` to `false` in `DS2SeamlessTextures.json` to bypass the handoff temporarily. Logs and the per-session replacement record are under `%LOCALAPPDATA%\Rama2120\DS2SeamlessTextures`. `INJECTION_ATTEMPTED` does not prove replacement; `INJECTION_VERIFIED` names a target whose replacement pixels matched.

To uninstall manually, close the game and remove only this mod's `version.dll`, `DS2TextureLauncher.exe`, `DS2SeamlessTextures.json` and `DS2STC-docs` after checking the included manifest. Do not remove TexMod, texture packs, other proxy DLLs, game files or saves. With Vortex, disable and purge this mod through Vortex.

Source, build instructions, MIT project license and MinHook attribution are in the separate source archive. Original TexMod, Return to Titan, MarkerPatch, dgVoodoo, ReShade, REST and Conduit assets are not redistributed. No public source repository is claimed.
