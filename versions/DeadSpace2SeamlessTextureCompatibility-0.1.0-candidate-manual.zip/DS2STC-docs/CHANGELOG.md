# Changelog

## 0.1.0-candidate — 2026-09-23

- Introduced the standalone DS2 version proxy and automatic TexMod companion.
- Added per-launch package discovery, Vortex file-symlink support, content validation, priorities, exact disables and duplicate handling.
- Added exact-content Return to Titan order and superseded-package profiles without bundling texture content.
- Added consent-based HTTPS acquisition with pinned original TexMod checksums.
- Added executable selection and package-list readback, runtime replacement evidence and visible failure reporting.
- Added isolated package/native/graphics tests and reversible full-stack live-test tooling.
- Validation is ongoing. Consult TEST-REPORT before any public release.
